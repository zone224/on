let handler = async (m, { conn, participants }) => {
  // if (participants.map(v=>v.jid).includes(global.conn.user.jid)) {
    global.DATABASE._data.chats[m.chat].isBanned = true
    m.reply('BOT Berhasil *DI NONAKTIFKAN* Untuk Grup Ini !')
  // } else m.reply('Ada nomor host disini...')
}
handler.help = ['off']
handler.tags = ['owner']
handler.command = /^off$/i
handler.owner = true
handler.group = false

module.exports = handler