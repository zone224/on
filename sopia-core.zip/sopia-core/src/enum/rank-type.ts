/*
 * rank-type.ts
 * Created on Tue Jul 21 2020
 *
 * Copyright (c) Tree Some. Licensed under the MIT License.
 */

export enum DateType {

	DAILY = 'daily',
	WEEKLY = 'weekly',
	MONTHLY = 'monthly',

}
