/*
 * api-casts-popular.ts
 * Created on Wed Jul 29 2020
 *
 * Copyright (c) Tree Some. Licensed under the MIT License.
 */

import { ApiCasts } from '../api-casts';

export class ApiCastsPopular extends ApiCasts {
	constructor() {
		super('popular');
	}
}
